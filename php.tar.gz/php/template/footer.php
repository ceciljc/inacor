<div class="footer">
    <div class="container">
        <div class="text-center">
            <p><a href="#">About Indonesia Corner for UG</a> | <a href="#">Privacy Policy</a> | <a href="#">Banner</a></p>
            <p>Please direct question or comment to the <a href="#">Webmaster</a></p>
            <p>Copyright &copy; Indonesia Corner for UG</p>
        </div>
        <p class="pull-right"><a href="#">Back to top</a></p>
    </div>
    
</div>